//
//  CordovaFrameworkTests.h
//  CordovaFrameworkTests
//
//  Created by Shazron Abdullah on 3/8/13.
//  Copyright (c) 2013 Apache Foundation. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface CordovaFrameworkTests : SenTestCase

@end
